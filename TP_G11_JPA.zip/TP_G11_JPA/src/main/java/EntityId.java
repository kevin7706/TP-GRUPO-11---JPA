import javax.persistence.*;

@MappedSuperclass
public abstract class EntityId {
    // @Id indica que es la Clave Primaria.
    // @GeneratedValue hace que se autoincremente (1, 2, 3...) en la base de datos.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

    // gys

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
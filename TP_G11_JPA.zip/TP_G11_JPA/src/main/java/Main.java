import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.Date;

public class Main {

    public static void main(String[] args) {

        // 1. Iniciar el contenedor de JPA mediante Persistence.createEntityManagerFactory y obtener EntityManager
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            // 2. Iniciar una transacción
            em.getTransaction().begin();

            // 3. Instanciar los objetos necesarios (Catálogos previos)
            // Primero creamos y guardamos el Usuario, PuntoVenta, Articulo, etc. 
            // Esto es necesario para que la Factura no dé error por relaciones faltantes.

            Usuario usuario = new Usuario();
            usuario.setUsuario("jperez");
            usuario.setClave("123456");
            usuario.setNombre("Juan");
            usuario.setApellido("Perez");
            em.persist(usuario); // Guardamos en BD

            PuntoVenta puntoVenta = new PuntoVenta();
            puntoVenta.setNumero(1);
            puntoVenta.setDescripcion("Sucursal Principal");
            puntoVenta.setTipoEmision("Factura Electronica");
            puntoVenta.setDomicilioComercial("Av. Siempreviva 742");
            puntoVenta.setFechaAlta(new Date()); // Campo obligatorio por AuditoriaApp
            puntoVenta.setUsuarioCarga(usuario); // ***
            puntoVenta.setFechaModificacion(new Date()); //***
            puntoVenta.setUsuarioModificacion(usuario); //***
            em.persist(puntoVenta); // Guardo en DB

            ListaPrecio listaP = new ListaPrecio();
            listaP.setCodigo("LP-01");
            listaP.setDenominacion("Lista General");
            listaP.setFechaAlta(new Date());
            listaP.setUsuarioCarga(usuario);
            listaP.setFechaModificacion(new Date());
            listaP.setUsuarioModificacion(usuario);
            em.persist(listaP);

            Articulo articulo = new Articulo();
            articulo.setCodigo("ART-001");
            articulo.setDenominacion("Monitor 24 Pulgadas");
            articulo.setFechaAlta(new Date());
            articulo.setUsuarioCarga(usuario);
            articulo.setFechaModificacion(new Date());
            articulo.setUsuarioModificacion(usuario);
            em.persist(articulo);

            ListaPrecioArticulo precioArticulo = new ListaPrecioArticulo();
            precioArticulo.setPrecioVenta(150000.0);
            precioArticulo.setArticulo(articulo);
            precioArticulo.setListaPrecio(listaP);
            precioArticulo.setFechaAlta(new Date());
            precioArticulo.setUsuarioCarga(usuario);
            precioArticulo.setFechaModificacion(new Date());
            precioArticulo.setUsuarioModificacion(usuario);
            em.persist(precioArticulo);

            // Creamos los nuevos objetos requeridos por la actualización del TP
            CondicionIva condicionIva = new CondicionIva();
            condicionIva.setCodigoAfip(1);
            condicionIva.setDenominacion("Responsable Inscripto");
            condicionIva.setFechaAlta(new Date());
            condicionIva.setUsuarioCarga(usuario);
            condicionIva.setFechaModificacion(new Date());
            condicionIva.setUsuarioModificacion(usuario);
            em.persist(condicionIva);

            TipoMoneda tipoMoneda = new TipoMoneda();
            tipoMoneda.setCodigoAfip("PES");
            tipoMoneda.setDenominacion("Pesos Argentinos");
            tipoMoneda.setSimbolo("$");
            tipoMoneda.setFechaAlta(new Date());
            tipoMoneda.setUsuarioCarga(usuario);
            tipoMoneda.setFechaModificacion(new Date());
            tipoMoneda.setUsuarioModificacion(usuario);
            em.persist(tipoMoneda);

            // 4. Crear una cabecera de FacturaVenta

            FacturaVenta facturaVenta = new FacturaVenta();
            facturaVenta.setNumero(10001L);
            facturaVenta.setFechaEmision(new Date());
            facturaVenta.setImporteTotal(150000.0);
            facturaVenta.setEstado("EMITIDA");
            facturaVenta.setPuntoVenta(puntoVenta);
            facturaVenta.setCondicionIva(condicionIva);
            facturaVenta.setTipoMoneda(tipoMoneda);
            // El cliente es nullable=true según el PDF, así que lo omitimos para no alargar tanto el Main, 
            // pero si quisieras podrías crear un Cliente, Contacto y Domicilio y agregarlo acá.

            // Campos de auditoría obligatorios heredados

            facturaVenta.setFechaAlta(new Date());
            facturaVenta.setUsuarioCarga(usuario);
            facturaVenta.setFechaModificacion(new Date());
            facturaVenta.setUsuarioModificacion(usuario);

            // Inicializar la lista de detalles si es null

            if (facturaVenta.getDetalles() == null) {
                facturaVenta.setDetalles(new ArrayList<>());
            }

            // Crear un ítem (FacturaVentaDetalle)

            FacturaVentaDetalle detalle1 = new FacturaVentaDetalle();
            detalle1.setCantidad(1);
            detalle1.setPrecioUnitario(150000.0);
            detalle1.setImporteSubtotal(150000.0);
            detalle1.setDescripcion("Monitor 24 Pulgadas Gamer");
            detalle1.setListaPrecioArticulo(precioArticulo);

            // ASOCIACIÓN BIDIRECCIONAL (La clave del ejercicio)
            // A) Le decimos al detalle quién es su padre (la factura)
            detalle1.setFactura(facturaVenta);
            // B) Le decimos a la factura que agregue a su hijo (el detalle)
            facturaVenta.getDetalles().add(detalle1);

            // 5. REQUISITO CLAVE: Persistir únicamente el objeto cabecera

            System.out.println("Guardando FacturaVenta...");
            em.persist(facturaVenta);
            // Como FacturaVenta tiene @OneToMany(cascade = CascadeType.ALL),
            // Hibernate detecta el 'detalle1' y le hace INSERT en la base de datos automáticamente.

            // 6. Finalizar la transacción
            em.getTransaction().commit();
            System.out.println("¡Transacción Exitosa! Factura y detalles insertados automáticamente en cascada.");

        } catch (Exception e) {
            // Si hay algún error (como un dato null), la transacción se cancela (rollback)
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("Ocurrió un error al intentar guardar en la base de datos:");
            e.printStackTrace();
        } finally {
            // 7. Cerrar el EntityManager y EntityManagerFactory
            em.close();
            emf.close();
            System.out.println("Conexiones a la base de datos cerradas.");
        }
    }
}
import os
import re

for root, _, files in os.walk('src/main/java'):
    for file in files:
        if file.endswith('.java'):
            path = os.path.join(root, file)
            with open(path, 'r') as f:
                content = f.read()

            # Find patterns like:
            # @JoinColumn(nullable = false)
            # @JoinColumn(name = "...")
            content = re.sub(
                r'@JoinColumn\(\s*nullable\s*=\s*(true|false)\s*\)\s*\n\s*@JoinColumn\(\s*name\s*=\s*("[^"]+")\s*\)',
                r'@JoinColumn(name = \2, nullable = \1)',
                content
            )
            
            # Find reverse patterns:
            # @JoinColumn(name = "...")
            # @JoinColumn(nullable = false)
            content = re.sub(
                r'@JoinColumn\(\s*name\s*=\s*("[^"]+")\s*\)\s*\n\s*@JoinColumn\(\s*nullable\s*=\s*(true|false)\s*\)',
                r'@JoinColumn(name = \1, nullable = \2)',
                content
            )

            with open(path, 'w') as f:
                f.write(content)
